class coleccion{
  acuDivisor(num){
    let cont = 1, acu = 0, r = 0
    while (cont < num) {
        r = num % cont
        if (r == 0) {
            acu = acu + cont
        }
        cont = cont + 1
    }
    return acu
}
divisor(){
    let res = 0
    let num = document.getElementById('numero').value
    let resp = document.getElementById('resp')
    num = parseInt(num)
    res = this.acuDivisor(num)
    resp.innerHTML = `La suma de los divisores del número ${num}, es: ${res}`

}
perfecto(){
    let acud = 0
    let num = document.getElementById("numero").value
    let resp = document.getElementById("resp")
    num = parseInt(num)
    acud = this.acuDivisor(num)
    if (acud == num) {
        resp.innerHTML = `${num} Es un número Perfecto`
    } else {
        resp.innerHTML = `${num} No es un número Perfecto`
    }

}
primo(){
    let pri = 0
    let num = document.getElementById('numero').value
    let resp = document.getElementById('resp')
    num = parseInt(num)
    pri = this.acuDivisor(num)
    if (pri == 1) {
        resp.innerHTML = `${num} Es un número Primo`
    } else {
        resp.innerHTML = `${num} No es un número Primo`
    }

}
prigeme(){
    let prige = 0
    let num1 = document.getElementById("nume1").value
    let num2 = document.getElementById("nume2").value
    num1 = parseInt(num1)
    num2 = parseInt(num2)
    let resp = document.getElementById("resp")
    prige = this.acuDivisor(num1, num2)
    if (prige == 1) {
        if (num1 - num2 == 2 || num1 - num2 == -2 ) {
            resp.innerHTML = `${num1} y ${num2} Son una pareja de números Primos Gemelos`
        } else {
            resp.innerHTML = `No son una pareja de números Primos Gemelos`
        }
    } else {
        resp.innerHTML = `Números sin compatibilidad para esta identificación !`
    }

}
    

   buscar() {

        // Obtenemos los valores ingresados por el usuario
        let valoresInput = document.getElementById("valor").value;
        let busquedaInput = document.getElementById("busqueda").value;
      
        // Convertimos la cadena de valores separados por coma en un arreglo
        let arreglo = valoresInput.split(",");
      
        // Realizamos la búsqueda en el arreglo con un bucle while
        let encontrado = false;
        let pos = 0;
      
        while (pos < arreglo.length && !encontrado) {
          if (arreglo[pos] === busquedaInput) {
            encontrado = true;
          } else {
            pos++;
          }
        }
      
        // Mostramos el resultado
        let resultadoElement = document.getElementById("resultado");
        if (encontrado) {
          resultadoElement.textContent = `El valor "${busquedaInput}" está en la posición ${pos} del arreglo.`;
        } else {
          resultadoElement.textContent = `El valor "${busquedaInput}" no se encontró en el arreglo.`;
        }
      }


      concatenar(){
        let cad1 = document.getElementById("cadena1").value;
        let cad2 = document.getElementById("cadena2").value;
        let resp =  cad1 + " "+ cad2;
        console.log(resp);
        document.getElementById("resultado").textContent = `Resultado: ${resp}`;
      }

      insertar(){
        let cadena = document.getElementById("cadena").value;
        let subcad = document.getElementById("subcadena").value;
        let pos = document.getElementById("pos").value;
        console.log(pos)

        
        if (pos < 0 || pos > cadena.length){
          document.getElementById("resultado").textContent = "La posicion no es valida"
        }
        //substing extrae el texto desde hasta la posicion indicada
        let inicial = cadena.substring(0, pos)
        let final = cadena.substring(pos)

        let resp = `Resultado: ${inicial}${subcad}${final} `
        document.getElementById("resultado").textContent = resp
      }

      eliminar(){
        let cadena = document.getElementById("cadena").value;
        let subcadena = document.getElementById("subcadena").value;
        let pos = cadena.indexOf(subcadena)


        if (pos !== -1){
          let resultado = cadena.substring(0, pos) + cadena.substring(pos + subcadena.length)
          console.log(resultado)
          document.getElementById("respuesta").textContent = `Resultado: ${resultado}`
        }else{
          console.log("no existe subcadena")
          document.getElementById("respuesta") = "No se encontro la subcadena"

        }
      }
       /* Ejercicio 9 */
    arreglo_cadena(){
      let arre = document.getElementById("arre").value
      let res = this.arreglo_cadena_funt(arre)
      document.getElementById("resp").innerHTML = res
  }

  arreglo_cadena_funt(arre){
      let cad = ``
      for(let i = 0; i < arre.length; i++){
          if(arre[i] != ';'){
              cad += arre[i]
          }else{
              cad += ', '
          }
      }
      return cad
  }
  /*  */
  
  /* Ejercicio 10*/
  mayor_arreglo(){
      let arre = document.getElementById("arre").value
      let res = this.mayor_arreglo_funt(arre)
      document.getElementById("resp").innerHTML = `El mayor elemento del arreglo es ${res}`
  }

  mayor_arreglo_funt(arre){
      arre = arre.split(';')
      let ma = parseInt(arre[0])
      for(let i = 1; i < arre.length; i++){
          if(parseInt(arre[i]) > ma){
              ma = arre[i]
          }
      }
      return ma
  }
  /*  */

  /* Ejercicio 11 */
  isbuscaArreglo(arreglo,buscado){
      let pos = 0, enc = false
      while (pos < arreglo.length && enc == false) {
          if (arreglo[pos] == buscado) {
              enc = true
          } else {
              pos++
          }
      }
      if (enc == true) {
          return pos
      } else {
          return -1
      }
  }
  buscarArreglo(){
      let arreglo = document.getElementById("numeros").value
      arreglo = arreglo.split(";")
      let buscado = document.getElementById("buscado").value
      let resp = document.getElementById("respuesta")
      let posi = this.isbuscaArreglo(arreglo, buscado)
      if (posi >=0) {
          resp.innerHTML = `${buscado} se encontró en la posicion:${posi} del arreglo`
      } else {
          resp.innerHTML = `${buscado} No se encontró en el arreglo`
      }
  }
  /*  */

  /* Ejercicio 12 */
  insertar_arreglo(){
      let arre = document.getElementById("arre").value
      arre = arre.split(';')
      let ins = document.getElementById("ins").value
      let pos = document.getElementById("pos").value
      let res = this.insertar_arreglo_funt(arre,ins,pos)
      document.getElementById("resp").innerHTML = res
       
  }

  insertar_arreglo_funt(arre,ins,pos){
      console.log(arre)
      let arreN = []
      let con = 0
     for(let i = 0; i < arre.length; i++){
          if(con != pos){
              arreN[con] = arre[i]
          }else{
              arreN[con] = ins
              i--
          }
          con++
     }
     return arreN
  }
  /*  */  
      
      
}

let ope = new coleccion()
