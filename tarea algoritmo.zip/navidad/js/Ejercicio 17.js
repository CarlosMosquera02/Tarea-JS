//Ejercicio 17) Base 10 a Base 16

//Número en Base 10
let decimal = 512;

//Número en Base 16
let resultado = decimal.toString(16);

console.log(decimal)
console.log(resultado)