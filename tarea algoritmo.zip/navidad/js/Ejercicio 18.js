//Ejercicio 18) Base 2 a Base 10

//Numero de Base 2
let binario = 101;

//Numero Base 10
let decimal = binario.toString(10);

console.log(binario);
console.log(decimal);