//Ejercicio 19) Base 2 a base 8

//Numero en base 2
let binario = 1010;

//Numero en base 8
let octal = binario.toString(8);

console.log(Binario);
console.log(Octal);