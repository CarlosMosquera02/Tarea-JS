//Base 2 a base 16

//Numero en Base 2
let binario = 1100;

//Numero en base 16
let hexadecimal = binario.toString(16);

console.log(binario);
console.log(hexadecimal);